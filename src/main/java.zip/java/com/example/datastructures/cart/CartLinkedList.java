package com.example.datastructures.cart;

/**
 * Singly linked list that serves as the customer's shopping cart.
 *
 * Responsibilities:
 *  - Add a product to the cart (inserts at front, O(1))
 *  - Remove a product by productId (O(n) traversal)
 *  - Update quantity for a product already in the cart
 *  - Check whether a product is already in the cart
 *  - Expose the full list for rendering
 */
public class CartLinkedList {

    private CartNode head;
    private int size;

    public CartLinkedList() {
        this.head = null;
        this.size = 0;
    }

    // ── Add ────────────────────────────────────────────────────────────────

    /**
     * If the product is already in the cart, increments its quantity by the
     * given amount.  Otherwise inserts a new node at the front of the list.
     */
    public void add(CartItem item) {
        CartNode existing = findNodeById(item.getProduct().getProductId());
        if (existing != null) {
            existing.getCartItem().setQuantity(
                existing.getCartItem().getQuantity() + item.getQuantity()
            );
            return;
        }
        CartNode newNode = new CartNode(item);
        newNode.setNext(head);
        head = newNode;
        size++;
    }

    // ── Remove ─────────────────────────────────────────────────────────────

    /**
     * Removes the node whose product ID matches.
     * Returns the removed CartItem so the caller can push it onto the undo stack.
     * Returns null if not found.
     */
    public CartItem remove(int productId) {
        if (isEmpty()) return null;

        if (head.getCartItem().getProduct().getProductId() == productId) {
            CartItem removed = head.getCartItem();
            head = head.getNext();
            size--;
            return removed;
        }

        CartNode current = head;
        while (current.getNext() != null) {
            if (current.getNext().getCartItem().getProduct().getProductId() == productId) {
                CartItem removed = current.getNext().getCartItem();
                current.setNext(current.getNext().getNext());
                size--;
                return removed;
            }
            current = current.getNext();
        }
        return null;
    }

    // ── Update quantity ────────────────────────────────────────────────────

    /**
     * Sets the quantity of an existing cart item.
     * Returns the old quantity so the caller can record it for undo.
     * Returns -1 if the product is not in the cart.
     */
    public int updateQuantity(int productId, int newQuantity) {
        CartNode node = findNodeById(productId);
        if (node == null) return -1;
        int oldQuantity = node.getCartItem().getQuantity();
        node.getCartItem().setQuantity(newQuantity);
        return oldQuantity;
    }

    // ── Lookup ─────────────────────────────────────────────────────────────

    public boolean contains(int productId) {
        return findNodeById(productId) != null;
    }

    public CartItem findById(int productId) {
        CartNode node = findNodeById(productId);
        return node != null ? node.getCartItem() : null;
    }

    private CartNode findNodeById(int productId) {
        CartNode current = head;
        while (current != null) {
            if (current.getCartItem().getProduct().getProductId() == productId)
                return current;
            current = current.getNext();
        }
        return null;
    }

    // ── State ──────────────────────────────────────────────────────────────

    public CartNode getHead()  { return head; }
    public int      getSize()  { return size; }
    public boolean  isEmpty()  { return head == null; }

    /** Clear the entire cart */
    public void clear() {
        head = null;
        size = 0;
    }
}