package com.example.datastructures.cart;

/**
 * Represents a single reversible cart action.
 *
 * Stored on the undo stack so the customer can revert recent changes.
 * A mirrored copy is pushed onto the redo stack when the action is undone.
 *
 * Action types:
 *   ADD      – a product was added to the cart
 *   REMOVE   – a product was removed from the cart
 *   QUANTITY – a product's quantity was changed
 */
public class CartAction {

    public enum Type { ADD, REMOVE, QUANTITY }

    private final Type      type;
    private final CartItem  item;        // snapshot of the item at time of action
    private final int       oldQuantity; // only meaningful for QUANTITY actions

    /** Constructor for ADD and REMOVE actions */
    public CartAction(Type type, CartItem item) {
        this.type        = type;
        this.item        = new CartItem(item); // defensive copy
        this.oldQuantity = item.getQuantity();
    }

    /** Constructor for QUANTITY actions – stores both old and new quantity */
    public CartAction(Type type, CartItem item, int oldQuantity) {
        this.type        = type;
        this.item        = new CartItem(item); // defensive copy
        this.oldQuantity = oldQuantity;
    }

    // ── Accessors ──────────────────────────────────────────────────────────
    public Type     getType()        { return type; }
    public CartItem getItem()        { return item; }
    public int      getOldQuantity() { return oldQuantity; }

    @Override
    public String toString() {
        return "CartAction[" + type + " " + item + "]";
    }
}