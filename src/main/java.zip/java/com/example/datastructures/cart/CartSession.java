package com.example.datastructures.cart;

import com.example.datastructures.product.ProductBst;
import com.example.models.Product;
import com.vaadin.flow.server.VaadinSession;
/**
 * Session-scoped bean — one instance per browser session (one per customer).
 *
 * Owns:
 *   cartList  — LinkedList tracking what the customer has added
 *   undoStack — CartActions that can be reversed
 *   redoStack — CartActions that were undone and can be re-applied
 *   bst       — BST loaded with the same products as the product page,
 *               used to quickly locate a product inside the cart by ID or name
 *
 * All cart mutations go through this class so that the undo/redo stacks
 * stay consistent.
 */

public class CartSession {

    private final CartLinkedList        cartList;
    private final CartStack<CartAction> undoStack;
    private final CartStack<CartAction> redoStack;

    // BST over the cart's own products for fast lookup by id/name
    private final ProductBst cartBst;

    public CartSession() {
        cartList  = new CartLinkedList();
        undoStack = new CartStack<>();
        redoStack = new CartStack<>();
        cartBst   = new ProductBst();
    }

    // ── Add ────────────────────────────────────────────────────────────────

    /**
     * Adds one unit of a product to the cart.
     * Pushes an ADD action onto the undo stack.
     * Clears the redo stack (a new action invalidates any undone future).
     */
    public void addToCart(Product product) {
        CartItem item = new CartItem(product, 1);
        cartList.add(item);

        // Index in BST so cart can be searched fast
        if (cartBst.searchById(product.getProductId()) == null) {
            cartBst.insert(product);
        }

        undoStack.push(new CartAction(CartAction.Type.ADD, item));
        redoStack.clear();
    }

    // ── Remove ─────────────────────────────────────────────────────────────

    /**
     * Removes a product from the cart by product ID.
     * Pushes a REMOVE action onto the undo stack.
     */
    public boolean removeFromCart(int productId) {
        CartItem removed = cartList.remove(productId);
        if (removed == null) return false;

        cartBst.delete(productId);
        undoStack.push(new CartAction(CartAction.Type.REMOVE, removed));
        redoStack.clear();
        return true;
    }

    // ── Update quantity ────────────────────────────────────────────────────

    /**
     * Updates the quantity of a cart item.
     * Pushes a QUANTITY action onto the undo stack.
     */
    public boolean updateQuantity(int productId, int newQuantity) {
        if (newQuantity <= 0) return removeFromCart(productId);

        CartItem existing = cartList.findById(productId);
        if (existing == null) return false;

        int oldQty = cartList.updateQuantity(productId, newQuantity);
        CartItem snapshot = new CartItem(existing);
        snapshot.setQuantity(newQuantity);

        undoStack.push(new CartAction(CartAction.Type.QUANTITY, snapshot, oldQty));
        redoStack.clear();
        return true;
    }

    // ── Undo ───────────────────────────────────────────────────────────────

    /**
     * Reverts the last cart action.
     * Returns a description of what was undone, or null if nothing to undo.
     */
    public String undo() {
        if (undoStack.isEmpty()) return null;

        CartAction action = undoStack.pop();

        switch (action.getType()) {

            case ADD:
                // Undo ADD → remove from cart
                cartList.remove(action.getItem().getProduct().getProductId());
                cartBst.delete(action.getItem().getProduct().getProductId());
                redoStack.push(action);
                return "Removed \"" + action.getItem().getProduct().getProductName() + "\" from cart.";

            case REMOVE:
                // Undo REMOVE → add back
                cartList.add(action.getItem());
                cartBst.insert(action.getItem().getProduct());
                redoStack.push(action);
                return "Restored \"" + action.getItem().getProduct().getProductName() + "\" to cart.";

            case QUANTITY:
                // Undo QUANTITY → restore old quantity
                cartList.updateQuantity(
                    action.getItem().getProduct().getProductId(),
                    action.getOldQuantity()
                );
                redoStack.push(action);
                return "Quantity of \"" + action.getItem().getProduct().getProductName()
                    + "\" reverted to " + action.getOldQuantity() + ".";
        }
        return null;
    }

    // ── Redo ───────────────────────────────────────────────────────────────

    /**
     * Re-applies the last undone action.
     */
    public String redo() {
        if (redoStack.isEmpty()) return null;

        CartAction action = redoStack.pop();

        switch (action.getType()) {

            case ADD:
                cartList.add(action.getItem());
                cartBst.insert(action.getItem().getProduct());
                undoStack.push(action);
                return "Re-added \"" + action.getItem().getProduct().getProductName() + "\".";

            case REMOVE:
                cartList.remove(action.getItem().getProduct().getProductId());
                cartBst.delete(action.getItem().getProduct().getProductId());
                undoStack.push(action);
                return "Removed \"" + action.getItem().getProduct().getProductName() + "\" again.";

            case QUANTITY:
                cartList.updateQuantity(
                    action.getItem().getProduct().getProductId(),
                    action.getItem().getQuantity()
                );
                undoStack.push(action);
                return "Quantity of \"" + action.getItem().getProduct().getProductName()
                    + "\" set back to " + action.getItem().getQuantity() + ".";
        }
        return null;
    }

    // ── Search inside cart (BST) ───────────────────────────────────────────

    public Product findInCartById(int productId) {
        return cartBst.searchById(productId);
    }

    // ── Accessors ──────────────────────────────────────────────────────────

    public CartLinkedList        getCartList()  { return cartList; }
    public CartStack<CartAction> getUndoStack() { return undoStack; }
    public CartStack<CartAction> getRedoStack() { return redoStack; }

    public boolean canUndo() { return !undoStack.isEmpty(); }
    public boolean canRedo() { return !redoStack.isEmpty(); }
    public int     cartSize() { return cartList.getSize(); }
}