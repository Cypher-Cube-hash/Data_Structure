package com.example.services;

import org.springframework.stereotype.Service;

import com.example.datastructures.product.ProductBst;
import com.example.datastructures.product.ProductLinkedList;
import com.example.datastructures.product.ProductList;
import com.example.models.Product;
import com.example.repositories.ProductRepository;

@Service
public class ProductServices {

    private final ProductRepository productRepository;

    // LinkedList — primary store: fast O(1) insertion/deletion at front
    private final ProductLinkedList linkedList;

    // BST — secondary index: fast O(log n) search by ID or name
    private final ProductBst bst;

    public ProductServices(ProductRepository productRepository) {
        this.productRepository = productRepository;
        this.linkedList = new ProductLinkedList();
        this.bst = new ProductBst();
        loadDataFromDB();
    }

    /** On startup, load all DB records into both structures */
    private void loadDataFromDB() {
        Iterable<Product> products = productRepository.findAll();
        for (Product p : products) {
            linkedList.addToBack(p);
            bst.insert(p);
        }
    }

    /** Return every product (from the linked list) */
    public ProductList getAllProducts() {
        return linkedList.toList();
    }

    /**
     * Fast lookup by ID via the BST — O(log n).
     * Falls back to the linked list only if the BST misses (should not happen
     * in normal operation).
     */
    public Product getById(int id) {
        Product found = bst.searchById(id);
        return found != null ? found : linkedList.findById(id);
    }

    /**
     * Full-text name search via the BST — traverses every node looking for
     * a case-insensitive substring match.
     */
    public ProductList searchByName(String name) {
        return bst.searchByName(name);
    }

    /**
     * Persist to DB, then insert into both in-memory structures so they stay
     * in sync.  The saved entity (with its auto-generated ID) is what we
     * index — not the transient object passed in.
     */
    public Product addProduct(Product product) {
        Product saved = productRepository.save(product);
        linkedList.addToBack(saved);
        bst.insert(saved);
        return saved;
    }

    /**
     * Remove from DB and keep both structures consistent.
     */
    public boolean deleteProduct(int id) {
        productRepository.deleteById(id);
        bst.delete(id);
        return linkedList.remove(id);
    }

    /** Total number of products currently in the linked list */
    public int count() {
        return linkedList.getSize();
    }
}